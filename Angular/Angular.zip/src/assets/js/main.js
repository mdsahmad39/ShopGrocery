$("button").click(function () {
 $("button").removeClass("active");
 $(this).addClass("active");
});